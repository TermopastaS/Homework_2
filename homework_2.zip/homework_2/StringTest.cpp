#include <gtest/gtest.h>
#include "homework_2.h"

TEST(StringTest, DefaultConstructor) {
    bmstu::string str;
    EXPECT_EQ(str.size(), 0);
    EXPECT_STREQ(str.c_str(), "");
}

TEST(StringTest, CStrConstructor) {
    bmstu::string str("Hello");
    EXPECT_EQ(str.size(), 5);
    EXPECT_STREQ(str.c_str(), "Hello");
}

TEST(StringTest, CopyConstructor) {
    bmstu::string str1("Hello");
    bmstu::string str2(str1);
    EXPECT_EQ(str2.size(), 5);
    EXPECT_STREQ(str2.c_str(), "Hello");
}

TEST(StringTest, MoveConstructor) {
    bmstu::string str1("Hello");
    bmstu::string str2(std::move(str1));

    EXPECT_EQ(str2.size(), 5);
    EXPECT_STREQ(str2.c_str(), "Hello");
    EXPECT_EQ(str1.c_str(), nullptr);
}

TEST(StringTest, Concatenation) {
    bmstu::string str1("Hello");
    bmstu::string str2(" World");

    bmstu::string result = str1 + str2;

    EXPECT_EQ(result.size(), 11);
    EXPECT_STREQ(result.c_str(), "Hello World");
}

TEST(StringTest, AppendString) {
    bmstu::string str("Hello");

    str += " World";

    EXPECT_EQ(str.size(), 11);
    EXPECT_STREQ(str.c_str(), "Hello World");
}

TEST(StringTest, AppendChar) {
    bmstu::string str("Hello");

    str += '!';

    EXPECT_EQ(str.size(), 6);
    EXPECT_STREQ(str.c_str(), "Hello!");
}

TEST(StringTest, IndexOperator) {
    bmstu::string str("Hello");

    EXPECT_EQ(str[0], 'H');
    EXPECT_EQ(str[4], 'o');
}

TEST(StringTest, AssignmentOperator) {
    bmstu::string str1("Hello");

    bmstu::string str2;
    str2 = str1;

    EXPECT_EQ(str2.size(), 5);
    EXPECT_STREQ(str2.c_str(), "Hello");
}

TEST(StringTest, SelfAssignment) {
    bmstu::string str("Hello");
    str = str;

    EXPECT_EQ(str.size(), 5);
    EXPECT_STREQ(str.c_str(), "Hello");
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
